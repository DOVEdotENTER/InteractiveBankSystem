package bankSystem;

import java.util.ArrayList;

public class Bank {
	
	private ArrayList<Account> accounts = new ArrayList<>();
	
	public boolean addAccount(Account acc) {
        
        accounts.add(acc);
        System.out.println("Account created for " + acc.getOwnerName());
        return true;
    }
	
	
	public Account findAccount(String accountNumber) {
		
		for (int i = 0; i < accounts.size(); i++) {
			if (accounts.get(i).getAccountNumber().equals(accountNumber)) {
				return accounts.get(i);
			}
			
		}
		return null;

	}
	
	public void printAllAccounts() {
		
		for (int i = 0; i < accounts.size(); i++) {
			System.out.println(accounts.get(i));
		}
	}


}

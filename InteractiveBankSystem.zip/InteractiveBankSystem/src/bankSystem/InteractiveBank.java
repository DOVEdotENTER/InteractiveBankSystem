package bankSystem;

import java.util.Scanner;

public class InteractiveBank {
	
	public static void main(String[] args) {
		
		Bank bank = new Bank();
		Scanner sc = new Scanner(System.in);
		boolean running = true;
		
		while (running) {
			
			System.out.println("\n--- Bank Menu ---");
			System.out.println("1. Create Savings Account");
			System.out.println("2. Create Checking Account");
			System.out.println("3. Deposit");
			System.out.println("4. Withdraw");
			System.out.println("5. View Account");
			System.out.println("6. Apply Interest to Savings");
			System.out.println("7. List All accounts");
			System.out.println("0. Exit");
			System.out.println("Enter Choice Number: ");
			
			String Choice = sc.nextLine();
			
			
			switch(Choice) {
            case "1":
                System.out.print("Owner name: ");
                String sName = sc.nextLine();
                System.out.print("Account number: ");
                String sNumber = sc.nextLine();
                System.out.print("Initial balance: ");
                double sBalance = Double.parseDouble(sc.nextLine());
                System.out.print("Interest rate (e.g., 0.02): ");
                double rate = Double.parseDouble(sc.nextLine());
                bank.addAccount(new SavingsAccount(sNumber, sName,
                		sBalance, rate));
                break;

            case "2":
                System.out.print("Owner name: ");
                String cName = sc.nextLine();
                System.out.print("Account number: ");
                String cNumber = sc.nextLine();
                System.out.print("Initial balance: ");
                double cBalance = Double.parseDouble(sc.nextLine());
                System.out.print("Overdraft limit: ");
                double overdraft = Double.parseDouble(sc.nextLine());
                bank.addAccount(new CheckingAccount(cNumber, cName, cBalance,
                		overdraft));
                break;

            case "3":
                System.out.print("Account number: ");
                String depAcc = sc.nextLine();
                Account depositAcc = bank.findAccount(depAcc);
                if(depositAcc != null) {
                    System.out.print("Amount: ");
                    double depAmount = Double.parseDouble(sc.nextLine());
                    depositAcc.deposit(depAmount);
                } else System.out.println("Account not found.");
                break;

            case "4":
                System.out.print("Account number: ");
                String withAcc = sc.nextLine();
                Account withdrawAcc = bank.findAccount(withAcc);
                if(withdrawAcc != null) {
                    System.out.print("Amount: ");
                    double withAmount = Double.parseDouble(sc.nextLine());
                    withdrawAcc.withdraw(withAmount);
                } else System.out.println("Account not found.");
                break;

            case "5":
                System.out.print("Account number: ");
                String viewAcc = sc.nextLine();
                Account acc = bank.findAccount(viewAcc);
                if(acc != null) System.out.println(acc);
                else System.out.println("Account not found.");
                break;

            case "6":
                System.out.print("Account number: ");
                String intAcc = sc.nextLine();
                Account iAcc = bank.findAccount(intAcc);
                if(iAcc instanceof SavingsAccount) {
                	((SavingsAccount)iAcc).applyInterest();
                }
                else System.out.println("Account is not a savings account.");
                break;

            case "7":
                bank.printAllAccounts();
                break;

            case "0":
                running = false;
                System.out.println("Goodbye!");
                break;

            default:
                System.out.println("Invalid option.");
        }
    }
    sc.close();
			
		
	}

}

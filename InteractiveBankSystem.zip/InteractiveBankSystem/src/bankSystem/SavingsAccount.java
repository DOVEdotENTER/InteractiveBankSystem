package bankSystem;

public class SavingsAccount extends Account{
	
	private double interestRate;
	
	public SavingsAccount(String accountNumber, String ownerName,
			double initialBalance, double interestRate) {
		
		super(accountNumber, ownerName, initialBalance);
		this.interestRate = interestRate;
		
	}
	
	public void applyInterest() {
		
		balance += balance * interestRate;
		System.out.println("Interest applied.");
		
	}
	
	@Override
	public void withdraw(double amount) {
		
		if (amount <= balance) {
			balance -= amount;
			
		} else {
			System.out.println("Insufficient funds.");

		}
	}

}

package bankSystem;


public abstract class Account {
	
	private String accountNumber;
	private String ownerName;
	protected double balance;
	
	public Account(String accountNumber, String name, double initialBalance ) {
		
		this.accountNumber = accountNumber;
		ownerName = name;
		balance = initialBalance;
		
	}
	
	public String getAccountNumber() {
		return this.accountNumber;
	}
	
	public String getOwnerName() {
		return this.ownerName;
	}
	
	public double getBalance() {
		return this.balance;
	}
	
	public void deposit(double amount) {
		
		if (amount > 0) {
			balance += amount;
			
		} else {
			System.out.println("Deposite must be positive!");
			
		}
	}
	
	public abstract void withdraw(double amount);
	
	@Override
	public String toString() {
		return ownerName + " - " + accountNumber + " : $" + balance;
	}

}

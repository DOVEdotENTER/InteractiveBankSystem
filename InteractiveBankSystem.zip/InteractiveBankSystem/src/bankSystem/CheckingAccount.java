package bankSystem;

public class CheckingAccount extends Account {
	
	private double overdraftLimit;
	
	public CheckingAccount(String accountNumber, String ownerName,
			double initialBalance, double overdraftLimit) {
		
		super(accountNumber, ownerName, initialBalance);
		this.overdraftLimit = overdraftLimit;
		
	}
	
	@Override 
	public void withdraw(double amount) {
		
		if (amount <= balance + overdraftLimit) {
			balance -= amount;
			
		} else {
			System.out.println("Exceeded overdraft limit.");
			
		}
	}
	

}
